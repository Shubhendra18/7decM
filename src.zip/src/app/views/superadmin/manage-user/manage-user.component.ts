import { Component, OnInit } from '@angular/core';
import {
  faUser,
  faEnvelope,
  faRoute,
  faLock,
} from '@fortawesome/free-solid-svg-icons';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/resources/custom-validators';
@Component({
  selector: 'app-manage-user',
  templateUrl: './manage-user.component.html',
  styleUrls: ['./manage-user.component.scss'],
})
export class ManageUserComponent implements OnInit {
  faUser = faUser;
  faEnvelope = faEnvelope;
  faRoute = faRoute;
  faLock = faLock;
  public frmreset: FormGroup;
  defaultroles:any=null;

  constructor(private fb: FormBuilder) {
    this.frmreset = this.createSignupForm();
  }

  ngOnInit(): void {}

  createSignupForm(): FormGroup {
    return this.fb.group(
      {

        password: [
          null,
          Validators.compose([
            Validators.required,
            CustomValidators.patternValidator(/\d/, {
              hasNumber: true,
            }),
            CustomValidators.patternValidator(/[A-Z]/, {
              hasCapitalCase: true,
            }),
            CustomValidators.patternValidator(/[a-z]/, {
              hasSmallCase: true,
            }),
            CustomValidators.patternValidator(
              /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
              {
                hasSpecialCharacters: true,
              }
            ),
            Validators.minLength(8),
          ]),
        ],
        confirmPassword: [null, Validators.compose([Validators.required])],

      },
      {
        validator: CustomValidators.passwordMatchValidator,
      }
    );
  }
  resetpassword(){

  }
}
