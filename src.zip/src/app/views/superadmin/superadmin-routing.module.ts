import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { AddDomainComponent } from './add-domain/add-domain.component';
import { APIConfigComponent } from './api-config/api-config.component';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Super Admin',
    },
    children: [
      {
        path: '',
        redirectTo: 'user-management',
      },
      {
        path: 'user-management',
        component: ManageUserComponent,
        data: {
          title: 'User Management',
        },
      },
      {
        path: 'add-domain',
        component: AddDomainComponent,
        data: {
          title: 'Add Domain',
        },
      },
      {
        path: 'api-config',
        component: APIConfigComponent,
        data: {
          title: 'API Config',
        },
      },
    ],
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SuperAdminRoutingModule {}
