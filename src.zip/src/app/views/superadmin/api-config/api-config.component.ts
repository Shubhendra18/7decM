import { Component, OnInit } from '@angular/core';
import {
  faUser,
  faEnvelope,
  faRoute,
  faLock,
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-api-config',
  templateUrl: './api-config.component.html',
  styleUrls: ['./api-config.component.scss'],
})
export class APIConfigComponent implements OnInit {
  faUser = faUser;
  faEnvelope = faEnvelope;
  faRoute = faRoute;
  faLock = faLock;
  constructor() {}

  ngOnInit(): void {}
}
