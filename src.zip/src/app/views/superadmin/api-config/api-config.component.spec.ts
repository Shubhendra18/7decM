import { ComponentFixture, TestBed } from '@angular/core/testing';

import { APIConfigComponent } from './api-config.component';

describe('APIConfigComponent', () => {
  let component: APIConfigComponent;
  let fixture: ComponentFixture<APIConfigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ APIConfigComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(APIConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
