import { Component, OnInit } from '@angular/core';
import {
  faUser,
  faEnvelope,
  faRoute,
  faLock,
} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-add-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.scss'],
})
export class AddDomainComponent implements OnInit {
  faUser = faUser;
  faEnvelope = faEnvelope;
  faRoute = faRoute;
  faLock = faLock;
  constructor() {}

  ngOnInit(): void {}
}
