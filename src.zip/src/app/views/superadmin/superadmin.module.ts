import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {
  ButtonGroupModule,
  ButtonModule,
  CardModule,
  CollapseModule,
  DropdownModule,
  FormModule,
  GridModule,
  ModalModule,
  NavbarModule,
  NavModule,
  PopoverModule,
  SharedModule,
  UtilitiesModule,
} from '@coreui/angular';
import { FormsModule } from '@angular/forms';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DataTablesModule } from 'angular-datatables';
import { SuperAdminRoutingModule } from './superadmin-routing.module';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { AddDomainComponent } from './add-domain/add-domain.component';
import { APIConfigComponent } from './api-config/api-config.component';

import { IconModule } from '@coreui/icons-angular';

@NgModule({
  declarations: [ManageUserComponent, AddDomainComponent, APIConfigComponent],
  imports: [
    FormsModule,
    CommonModule,
    SuperAdminRoutingModule,
    ButtonModule,
    ButtonGroupModule,
    GridModule,
    IconModule,
    CardModule,
    UtilitiesModule,
    PopoverModule,
    ModalModule,
    DropdownModule,
    SharedModule,
    FormModule,
    ReactiveFormsModule,
    NavbarModule,
    CollapseModule,
    NavModule,
    NavbarModule,
    DataTablesModule,
    FontAwesomeModule,
  ],
})
export class SuperadminModule {}
