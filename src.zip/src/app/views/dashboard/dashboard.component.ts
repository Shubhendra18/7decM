import { Component, OnInit } from '@angular/core';
import { MapserviceService } from 'src/app/mapservice.service';

interface IUser {
  name: string;
  state: string;
  registered: string;
  country: string;
  usage: number;
  period: string;
  payment: string;
  activity: string;
  avatar: string;
  status: string;
  color: string;
}

@Component({
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  arrDate: any = [];
  arrTotal: any = [];
  arrSuccess: any = [];
  arrPending: any = [];
  chartBarData: any = {};
  chartPieData: any = {};
  Report: any = [];

  constructor(
    private service: MapserviceService
  ) {}

  ngOnInit() {
    this.service.GetValueRealizationReport().subscribe((k: any) => {
      this.Report = k;
    });
    this.service.GetReport().subscribe((k: any) => {
      for (let index = 0; index < k.length; index++) {
        this.arrDate.push(k[index].createdDate);
        this.arrTotal.push(k[index].request);
        this.arrSuccess.push(k[index].success);
        this.arrPending.push(k[index].failed);
      }
      this.chartBarData = {
        labels: this.arrDate,
        datasets: [

          {
            label: 'Success',
            backgroundColor: '#3b5998',
            data: this.arrSuccess,
          },
          {
            label: 'Failed',
            backgroundColor: '#e86767',
            data: this.arrPending,
          },
        ],
      };
    });

    this.service.GetPieReport().subscribe((k: any) => {
      this.chartPieData = {
        labels: [ 'Success', 'Failed'],
        datasets: [
          {
            data: [ k.success, k.failed],
            backgroundColor: ['#FFCE56', '#FF6384'],
            hoverBackgroundColor: [ '#FFCE56', '#FF6384'],

          },
        ],

      };
    });
  }
}
