import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import { faEye, faCircleInfo } from '@fortawesome/free-solid-svg-icons';
import { MapserviceService } from 'src/app/mapservice.service';


@Component({
  selector: 'app-request-status',
  templateUrl: './request-status.component.html',
  styleUrls: ['./request-status.component.scss'],
})
export class RequestStatusComponent implements OnInit, OnDestroy {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  faEye = faEye;
  faCircleInfo = faCircleInfo;
  Report: any = [];
  visible = true;
  public liveDemoVisible = false;
  jsonPayload: string = '';
  constructor(private service: MapserviceService) {}

  ngOnInit() {
    setTimeout(() => {
      this.visible = !this.visible;
    }, 3000);
    this.service.GetRequestReport().subscribe((k: any) => {
      this.Report = k;
      this.dtTrigger.next(0);
    });
    this.dtOptions = {
      pageLength: 10,
      pagingType: 'full_numbers',
      dom: 'lfrtip',
      paging: true,
    };
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  trackByFn(index: number, item: any) {
    return index;
  }
  toggleLiveDemo() {
    this.liveDemoVisible = !this.liveDemoVisible;
  }

  handleLiveDemoChange(event: boolean) {
    this.liveDemoVisible = event;
  }
  data(jsonPayload: any) {
    this.jsonPayload = JSON.parse(jsonPayload);
  }
  Bulkdata(bulkJsonPayload: any) {
    this.jsonPayload = JSON.parse(bulkJsonPayload);
  }
}
