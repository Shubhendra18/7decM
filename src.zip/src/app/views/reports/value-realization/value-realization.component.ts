import { Component, OnInit } from '@angular/core';
import { faCircleInfo, faEye } from '@fortawesome/free-solid-svg-icons';
import { Subject } from 'rxjs';
import { MapserviceService } from 'src/app/mapservice.service';
@Component({
  selector: 'app-value-status',
  templateUrl: './value-realization.component.html',
  styleUrls: ['./value-realization.component.scss'],
})
export class ValueRealizationComponent implements OnInit {
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  faEye = faEye;
  faCircleInfo = faCircleInfo;
  Report: any = [];
  visible = true;
  public liveDemoVisible = false;

  constructor(private service: MapserviceService) {}

  ngOnInit() {
    this.service.GetValueRealizationReport().subscribe((k: any) => {
      this.Report = k;
    });
  }

  trackByFn(index: number, item: any) {
    return index;
  }
}
