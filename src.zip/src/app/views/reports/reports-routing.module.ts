import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RequestStatusComponent } from './request-status/request-status.component';
import { ValueRealizationComponent } from './value-realization/value-realization.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Reports',
    },
    children: [
      {
        path: '',
        redirectTo: 'request-status',
      },
      {
        path: 'request-status',
        component: RequestStatusComponent,
        data: {
          title: 'Request Status',
        },
      },
      {
        path: 'value-realization',
        component: ValueRealizationComponent,
        data: {
          title: 'Value Realization',
        },
      },

    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReportsRoutingModule {}
