import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import {
  ButtonGroupModule,
  ButtonModule,
  CardModule,
  CollapseModule,
  DropdownModule,
  FormModule,
  GridModule, ModalModule, NavbarModule,
  NavModule, PopoverModule, SharedModule,
  UtilitiesModule
} from '@coreui/angular';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DataTablesModule } from 'angular-datatables';
import { ReportsRoutingModule } from './reports-routing.module';
import { RequestStatusComponent } from './request-status/request-status.component';
import { ValueRealizationComponent } from './value-realization/value-realization.component';

import { IconModule } from '@coreui/icons-angular';

@NgModule({
  declarations: [RequestStatusComponent, ValueRealizationComponent],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    ButtonModule,
    ButtonGroupModule,
    GridModule,
    IconModule,
    CardModule,
    UtilitiesModule,
    PopoverModule,
    ModalModule,
    DropdownModule,
    SharedModule,
    FormModule,
    ReactiveFormsModule,
    NavbarModule,
    CollapseModule,
    NavModule,
    NavbarModule,
    DataTablesModule,
    FontAwesomeModule,
  ]
})
export class ReportsModule {}
