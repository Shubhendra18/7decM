import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MapserviceService } from 'src/app/mapservice.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  customStylesValidated = false;

  constructor(
    private service: MapserviceService,
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {}
  login(logindata: any) {
    this.spinner.show();
    this.service.Login(logindata.value).subscribe(
      (k: any) => {
        if (k['isAuthSuccessful'] == true) {
          localStorage.setItem('Token', k['token']);
          localStorage.setItem('Role', k.result['userRole']);
          this.spinner.hide();
          this.router.navigate(['/dashboard']);
        } else {
          this.toastr.error('Invalid Credentials', 'Login Failed');
          this.spinner.hide();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 401) {
          this.toastr.error('Invalid Credentials', 'Login Failed');
          this.spinner.hide();
        }
      }
    );
  }
}
