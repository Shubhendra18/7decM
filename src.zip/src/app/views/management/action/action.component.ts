import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import {
  faEnvelope,
  faLocationDot,
  faRotate,
  faRotateRight,
  faFileCsv, faCircleInfo
} from '@fortawesome/free-solid-svg-icons';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MapserviceService } from 'src/app/mapservice.service';
import Swal from 'sweetalert2';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/resources/custom-validators';

@Component({
  selector: 'app-accordions',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.scss'],
})
export class ActionComponent implements OnInit {
  Snow :any;
  taskData: any = {};
  IsAssign: boolean = true;
  IsTaskshow: boolean = false;
  sysIdforAction: string = '';

  public password1: any = '';
  public password: any = '';
  public isPasswordInvalid: boolean = true;
  public frmreset: FormGroup;
  @ViewChild('tab_general') tg: ElementRef | any;
  @ViewChild('tab_general') tgg: ElementRef | any;

  @ViewChild('content') content: any;
  BulkReqData: any[] = [];

  faLocationDot = faLocationDot;
  faEnvelope = faEnvelope;
  faRotateRight = faRotateRight;
  faRotate = faRotate;
  faFileCsv = faFileCsv;
  faCircleInfo = faCircleInfo;


  isShown: boolean = false;
  isShown2: boolean = false;
  isShown3: boolean = false;
  isShown4: boolean = false;
  istabActive: boolean = true;
  CreateOU: any = 'CreateOU';
  UpdateOU: any = 'UpdateOU';
  isShownOU: boolean = false;
  isShownBulk: boolean = false;
  tblou: boolean = false;
  isChecked: boolean = false;
  dateD: any;
  //#region UserAD Vars
  AllActions: boolean = false;
  SearchUserForAction: boolean = false;
  SearchOUForAction: boolean = false;

  ADUserActionBasket: boolean = false;
  OUActionBasket: boolean = false;
  done: boolean = false;
  active: boolean = false;
  final: boolean = false;

  public visible = false;
  public visibleBulk = false;
  domainData: any = [];
  defaultdomain = null;

  userData: any = [];
  userDataEdit: any = {};
  defaultuser = null;

  ouData: any = [];
  ouGrouoData: any = [];
  defaultOu = null;

  RequestType: any = null;
  domainCodeforSelect: any = null;
  defaultCountry = null;
  searchedKeyword: string = '';
  countryRegionCode: any = null;
  countryCode: string = '';
  ManagedBy: any = null;

  continue: boolean = true;
  ActionName: number = 0;
  UserPrincipleNameForAction: string = '';
  DomainCodeForAction: string = '';
  OUForAction: string = '';
  IsEnableForAction: boolean = false;
  OUNameForAction: string = '';
  OUGroupNameForAction: string = '';

  lines: any = [];
  linesR: any = [];

  //#endregion
  //#region CreateUserModel
  city: string = '';
  company: string = '';
  department: string = '';
  descriptionD: string = '';
  domainCode: string = '';
  fax: string = '';
  firstName: string = '';
  homePhoneNumber: string = '';
  initials: string = '';
  ipPhone: string = '';
  jobTitle: string = '';
  lastName: string = '';
  mobile: string = '';
  notess: string = '';
  office: string = '';
  pager: string = '';
  pobox: string = '';
  stateProvince: string = '';
  street: string = '';
  telephoneNumber: string = '';
  userPrincipalName: string = '';
  webPage: string = '';
  zipPostalCode: string = '';
  manager: any = null;
  //#endregion

  //#region CreateOUModel
  organizationalUnitName: string = '';
  organizationalUnitDescription: string = '';
  ouManagedByType: any = null;
  adGroupData: any = [];
  manageByType: string = '';
  //#endregion


  //#region CreateOUGroupModel
  organizationalUnit: any = null;
  groupName: string = '';
  name: string = '';
  displayName: string = '';
  description: string = '';
  CreateADOUGroup: any = 'CreateADOUGroup';
  UpdateADOUGroup: any = 'UpdateADOUGroup';
  DeleteADOUGroup: any = 'DeleteADOUGroup';

  //#endregion
  Details = [
    { name: 'jobTitle', label: 'Job Title', value: null, isrequire: true },
    { name: 'department', label: 'Department', value: null, isrequire: true },
    { name: 'company', label: 'Company', value: null, isrequire: false },

    {
      name: 'homePhoneNumber',
      label: 'Home phone',
      value: null,
      isrequire: false,
    },
    { name: 'pager', label: 'Pager', value: null, isrequire: false },
    {
      name: 'mobile',
      label: 'Mobile phone number',
      value: null,
      isrequire: false,
    },
    { name: 'fax', label: 'Fax number', value: null, isrequire: false },
    { name: 'ipPhone', label: 'IP Phone', value: null, isrequire: false },
  ];
  AddressDetails = [
    { name: 'street', label: 'Street', value: null },
    { name: 'pobox', label: 'P.O. Box', value: null },
    { name: 'city', label: 'City', value: null },
    { name: 'stateProvince', label: 'State/ province', value: null },
    { name: 'zipPostalCode', label: 'Zip/ Postal code', value: null },
  ];
  //#region  Country
  CountryList = [
    { code: 'AQ', name: 'Antarctica' },
    { code: 'AG', name: 'Antigua and Barbuda' },
    { code: 'AR', name: 'Argentina' },
    { code: 'AM', name: 'Armenia' },
    { code: 'AW', name: 'Aruba' },
    { code: 'AU', name: 'Australia' },
    { code: 'AT', name: 'Austria' },
    { code: 'AZ', name: 'Azerbaijan' },
    { code: 'BS', name: 'Bahamas' },
    { code: 'BH', name: 'Bahrain' },
    { code: 'BD', name: 'Bangladesh' },
    { code: 'BB', name: 'Barbados' },
    { code: 'BY', name: 'Belarus' },
    { code: 'BE', name: 'Belgium' },
    { code: 'BZ', name: 'Belize' },
    { code: 'BJ', name: 'Benin' },
    { code: 'BM', name: 'Bermuda' },
    { code: 'BT', name: 'Bhutan' },
    { code: 'BO', name: 'Bolivia' },
    { code: 'BA', name: 'Bosnia and Herzegovina' },
    { code: 'BW', name: 'Botswana' },
    { code: 'BV', name: 'Bouvet Island' },
    { code: 'BR', name: 'Brazil' },
    { code: 'IO', name: 'British Indian Ocean Territory' },
    { code: 'BN', name: 'Brunei Darussalam' },
    { code: 'BG', name: 'Bulgaria' },
    { code: 'BF', name: 'Burkina Faso' },
    { code: 'BI', name: 'Burundi' },
    { code: 'KH', name: 'Cambodia' },
    { code: 'CM', name: 'Cameroon' },
    { code: 'CA', name: 'Canada' },
    { code: 'CV', name: 'Cape Verde' },
    { code: 'KY', name: 'Cayman Islands' },
    { code: 'CF', name: 'Central African Republic' },
    { code: 'TD', name: 'Chad' },
    { code: 'CL', name: 'Chile' },
    { code: 'CN', name: 'China' },
    { code: 'CX', name: 'Christmas Island' },
    { code: 'CC', name: 'Cocos (Keeling) Islands' },
    { code: 'CO', name: 'Colombia' },
    { code: 'KM', name: 'Comoros' },
    { code: 'CG', name: 'Congo' },
    { code: 'CD', name: 'Congo, The Democratic Republic of the' },
    { code: 'CK', name: 'Cook Islands' },
    { code: 'CR', name: 'Costa Rica' },
    { code: 'HR', name: 'Croatia' },
    { code: 'CY', name: 'Cyprus' },
    { code: 'CZ', name: 'Czech Republic' },
    { code: 'CI', name: "Côte d'Ivoire" },
    { code: 'DK', name: 'Denmark' },
    { code: 'DJ', name: 'Djibouti' },
    { code: 'DM', name: 'Dominica' },
    { code: 'DO', name: 'Dominican Republic' },
    { code: 'EC', name: 'Ecuador' },
    { code: 'EG', name: 'Egypt' },
    { code: 'SV', name: 'El Salvador' },
    { code: 'GQ', name: 'Equatorial Guinea' },
    { code: 'ER', name: 'Eritrea' },
    { code: 'EE', name: 'Estonia' },
    { code: 'ET', name: 'Ethiopia' },
    { code: 'FK', name: 'Falkland Islands (Malvinas)' },
    { code: 'FO', name: 'Faroe Islands' },
    { code: 'FJ', name: 'Fiji' },
    { code: 'FI', name: 'Finland' },
    { code: 'FR', name: 'France' },
    { code: 'GF', name: 'French Guiana' },
    { code: 'PF', name: 'French Polynesia' },
    { code: 'TF', name: 'French Southern Territories' },
    { code: 'GA', name: 'Gabon' },
    { code: 'GM', name: 'Gambia' },
    { code: 'GE', name: 'Georgia' },
    { code: 'DE', name: 'Germany' },
    { code: 'GH', name: 'Ghana' },
    { code: 'GI', name: 'Gibraltar' },
    { code: 'GR', name: 'Greece' },
    { code: 'GL', name: 'Greenland' },
    { code: 'GD', name: 'Grenada' },
    { code: 'GP', name: 'Guadeloupe' },
    { code: 'GU', name: 'Guam' },
    { code: 'GT', name: 'Guatemala' },
    { code: 'GG', name: 'Guernsey' },
    { code: 'GN', name: 'Guinea' },
    { code: 'GW', name: 'Guinea-Bissau' },
    { code: 'GY', name: 'Guyana' },
    { code: 'HT', name: 'Haiti' },
    { code: 'HM', name: 'Heard Island and McDonald Islands' },
    { code: 'VA', name: 'Holy See (Vatican City State)' },
    { code: 'HN', name: 'Honduras' },
    { code: 'HK', name: 'Hong Kong' },
    { code: 'HU', name: 'Hungary' },
    { code: 'IS', name: 'Iceland' },
    { code: 'IN', name: 'India' },
    { code: 'ID', name: 'Indonesia' },
    { code: 'IQ', name: 'Iraq' },
    { code: 'IE', name: 'Ireland' },
    { code: 'IM', name: 'Isle of Man' },
    { code: 'IL', name: 'Israel' },
    { code: 'IT', name: 'Italy' },
    { code: 'JM', name: 'Jamaica' },
    { code: 'JP', name: 'Japan' },
    { code: 'JE', name: 'Jersey' },
    { code: 'JO', name: 'Jordan' },
    { code: 'KZ', name: 'Kazakhstan' },
    { code: 'KE', name: 'Kenya' },
    { code: 'KI', name: 'Kiribati' },
    { code: 'KR', name: 'Korea, Republic of' },
    { code: 'KW', name: 'Kuwait' },
    { code: 'KG', name: 'Kyrgyzstan' },
    { code: 'LA', name: "Lao People's Democratic Republic" },
    { code: 'LV', name: 'Latvia' },
    { code: 'LB', name: 'Lebanon' },
    { code: 'LS', name: 'Lesotho' },
    { code: 'LR', name: 'Liberia' },
    { code: 'LY', name: 'Libyan Arab Jamahiriya' },
    { code: 'LI', name: 'Liechtenstein' },
    { code: 'LT', name: 'Lithuania' },
    { code: 'LU', name: 'Luxembourg' },
    { code: 'MO', name: 'Macao' },
    { code: 'MK', name: 'Macedonia, The former Yugoslav Republic of' },
    { code: 'MG', name: 'Madagascar' },
    { code: 'MW', name: 'Malawi' },
    { code: 'MY', name: 'Malaysia' },
    { code: 'MV', name: 'Maldives' },
    { code: 'ML', name: 'Mali' },
    { code: 'MT', name: 'Malta' },
    { code: 'MH', name: 'Marshall Islands' },
    { code: 'MQ', name: 'Martinique' },
    { code: 'MR', name: 'Mauritania' },
    { code: 'MU', name: 'Mauritius' },
    { code: 'YT', name: 'Mayotte' },
    { code: 'MX', name: 'Mexico' },
    { code: 'FM', name: 'Micronesia, Federated States of' },
    { code: 'MD', name: 'Moldova, Republic of' },
    { code: 'MC', name: 'Monaco' },
    { code: 'MN', name: 'Mongolia' },
    { code: 'ME', name: 'Montenegro' },
    { code: 'MS', name: 'Montserrat' },
    { code: 'MA', name: 'Morocco' },
    { code: 'MZ', name: 'Mozambique' },
    { code: 'MM', name: 'Myanmar' },
    { code: 'NA', name: 'Namibia' },
    { code: 'NR', name: 'Nauru' },
    { code: 'NP', name: 'Nepal' },
    { code: 'NL', name: 'Netherlands' },
    { code: 'AN', name: 'Netherlands Antilles' },
    { code: 'NC', name: 'New Caledonia' },
    { code: 'NZ', name: 'New Zealand' },
    { code: 'NI', name: 'Nicaragua' },
    { code: 'NE', name: 'Niger' },
    { code: 'NG', name: 'Nigeria' },
    { code: 'NU', name: 'Niue' },
    { code: 'NF', name: 'Norfolk Island' },
    { code: 'MP', name: 'Northern Mariana Islands' },
    { code: 'NO', name: 'Norway' },
    { code: 'OM', name: 'Oman' },
    { code: 'PK', name: 'Pakistan' },
    { code: 'PW', name: 'Palau' },
    { code: 'PS', name: 'Palestinian Territory' },
    { code: 'PA', name: 'Panama' },
    { code: 'PG', name: 'Papua New Guinea' },
    { code: 'PY', name: 'Paraguay' },
    { code: 'PE', name: 'Peru' },
    { code: 'PH', name: 'Philippines' },
    { code: 'PN', name: 'Pitcairn' },
    { code: 'PL', name: 'Poland' },
    { code: 'PT', name: 'Portugal' },
    { code: 'PR', name: 'Puerto Rico' },
    { code: 'QA', name: 'Qatar' },
    { code: 'RO', name: 'Romania' },
    { code: 'RU', name: 'Russian Federation' },
    { code: 'RW', name: 'Rwanda' },
    { code: 'RE', name: 'Réunion' },
    { code: 'BL', name: 'Saint Barthélemy' },
    { code: 'SH', name: 'Saint Helena' },
    { code: 'KN', name: 'Saint Kitts and Nevis' },
    { code: 'LC', name: 'Saint Lucia' },
    { code: 'MF', name: 'Saint Martin' },
    { code: 'PM', name: 'Saint Pierre and Miquelon' },
    { code: 'VC', name: 'Saint Vincent and the Grenadines' },
    { code: 'WS', name: 'Samoa' },
    { code: 'SM', name: 'San Marino' },
    { code: 'SA', name: 'Saudi Arabia' },
    { code: 'SN', name: 'Senegal' },
    { code: 'RS', name: 'Serbia' },
    { code: 'SC', name: 'Seychelles' },
    { code: 'SL', name: 'Sierra Leone' },
    { code: 'SG', name: 'Singapore' },
    { code: 'SK', name: 'Slovakia' },
    { code: 'SI', name: 'Slovenia' },
    { code: 'SB', name: 'Solomon Islands' },
    { code: 'SO', name: 'Somalia' },
    { code: 'ZA', name: 'South Africa' },
    { code: 'GS', name: 'South Georgia and the South Sandwich Islands' },
    { code: 'ES', name: 'Spain' },
    { code: 'LK', name: 'Sri Lanka' },
    { code: 'SR', name: 'Suriname' },
    { code: 'SJ', name: 'Svalbard and Jan Mayen' },
    { code: 'SZ', name: 'Swaziland' },
    { code: 'SE', name: 'Sweden' },
    { code: 'CH', name: 'Switzerland' },
    { code: 'ST', name: 'São Tome and Principe' },
    { code: 'TW', name: 'Taiwan' },
    { code: 'TJ', name: 'Tajikistan' },
    { code: 'TZ', name: 'Tanzania, United Republic of' },
    { code: 'TH', name: 'Thailand' },
    { code: 'TL', name: 'Timor-Leste' },
    { code: 'TG', name: 'Togo' },
    { code: 'TK', name: 'Tokelau' },
    { code: 'TO', name: 'Tonga' },
    { code: 'TT', name: 'Trinidad and Tobago' },
    { code: 'TN', name: 'Tunisia' },
    { code: 'TR', name: 'Turkey' },
    { code: 'TM', name: 'Turkmenistan' },
    { code: 'TC', name: 'Turks and Caicos Islands' },
    { code: 'TV', name: 'Tuvalu' },
    { code: 'UG', name: 'Uganda' },
    { code: 'UA', name: 'Ukraine' },
    { code: 'AE', name: 'United Arab Emirates' },
    { code: 'GB', name: 'United Kingdom' },
    { code: 'US', name: 'United States' },
    { code: 'UM', name: 'United States Minor Outlying Islands' },
    { code: 'UY', name: 'Uruguay' },
    { code: 'UZ', name: 'Uzbekistan' },
    { code: 'VU', name: 'Vanuatu' },
    { code: 'VE', name: 'Venezuela' },
    { code: 'VN', name: 'Viet Nam' },
    { code: 'VG', name: 'Virgin Islands, British' },
    { code: 'VI', name: 'Virgin Islands, U.S.' },
    { code: 'WF', name: 'Wallis and Futuna' },
    { code: 'EH', name: 'Western Sahara' },
    { code: 'YE', name: 'Yemen' },
    { code: 'ZM', name: 'Zambia' },
    { code: 'ZW', name: 'Zimbabwe' },
  ];
  //#endregion

  files: any[] = [];

  constructor(
    private sanitizer: DomSanitizer,
    private service: MapserviceService,
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private fb: FormBuilder
  ) {
    this.AllActions = true;
    this.SearchUserForAction = false;
    this.ADUserActionBasket = false;

    this.done = false;
    this.final = false;

    this.frmreset = this.createSignupForm();
  }

  //#region  ToggleCode
  toggleShow() {
    this.isShown2 = false;
    this.isShown3 = false;
    this.isShownOU = false;
    this.isShownBulk = false;

    this.isShown = !this.isShown;
  }
  toggleShow2() {
    this.isShown = false;
    this.isShown3 = false;
    this.isShownOU = false;
    this.isShownBulk = false;
    this.isShown2 = !this.isShown2;
  }
  toggleShowOU() {
    this.isShown2 = false;
    this.isShown = false;
    this.isShown3 = false;
    this.isShownBulk = false;
    this.isShownOU = !this.isShownOU;
  }
  AdUserAction(an: number) {
    this.AllActions = false;
    this.SearchUserForAction = true;
    this.searchedKeyword = '';

    this.isShown = false;
    this.isShown2 = false;
    this.isShown3 = !this.isShown3;

    this.done = true;
    this.active = true;

    this.ActionName = an;
  }
  continueAD() {
    this.AllActions = false;
    this.SearchUserForAction = false;

    this.done = true;
    this.active = true;
    this.final = true;
    this.ADUserActionBasket = !this.ADUserActionBasket;
    this.searchedKeyword = '';
    this.continue = false;
  }
  continueOU() {
    this.AllActions = false;
    this.SearchOUForAction = false;

    this.done = true;
    this.active = true;
    this.final = true;
    this.OUActionBasket = !this.OUActionBasket;
    this.searchedKeyword = '';
    this.continue = false;
  }
  onSelect(ev: any) {
    this.AllActions = false;
    this.SearchOUForAction = true;
    this.searchedKeyword = '';
    this.done = true;
    this.active = true;
    this.service.GetOUList(ev.target.value).subscribe((k) => {
      this.tblou = true;
      this.ouData = k;
      this.DomainCodeForAction = ev.target.value;
    });
  }

  onDomainSelect(ev: any) {
    this.AllActions = false;
    this.SearchOUForAction = true;
    this.searchedKeyword = '';
    this.done = true;
    this.active = true;
    this.service.GetOUList(ev.target.value).subscribe((k) => {
      this.ouData = k;
      this.DomainCodeForAction = ev.target.value;
    });
  }
  OUSelect(ev: any) {
    this.service.Getadougroupslist(this.DomainCodeForAction, ev.target.value).subscribe((k) => {
      this.tblou = true;
      this.ouGrouoData = k;
      this.OUForAction = ev.target.value;
    });
  }

  OUAction(an: number) {
    this.AllActions = false;
    this.SearchOUForAction = true;
    this.searchedKeyword = '';
    this.done = true;
    this.active = true;
    this.ActionName = an;
  }
  toggleLiveDemo() {
    this.visible = !this.visible;
  }
  toggleLiveDemoBulk() {
    this.visibleBulk = !this.visibleBulk;
  }

  handleLiveDemoChange(event: any) {
    this.visible = event;
  }
  handleLiveDemoChangeBulk(event: any) {
    this.visibleBulk = event;
  }






  back() {
    this.SearchUserForAction = false;
    this.AllActions = true;
    this.done = false;
    this.active = false;
    this.final = false;

    this.firstName = '';
    this.initials = '';
    this.lastName = '';
    this.office = '';
    this.userPrincipalName = '';
    this.telephoneNumber = '';
    this.webPage = '';
    this.domainCode = '';
    this.descriptionD = '';
    this.continue = true;
    this.ADUserActionBasket = false;
  }
  backOU() {
    this.SearchOUForAction = false;
    this.AllActions = true;
    this.done = false;
    this.active = false;
    this.final = false;
    this.continue = true;
    this.OUActionBasket = false;
  }
  backtoSearch() {
    this.SearchUserForAction = true;
    this.ADUserActionBasket = false;
    this.done = true;
    this.active = true;
  }
  backtoOUSearch() {
    this.SearchOUForAction = true;
    this.OUActionBasket = false;
    this.done = true;
    this.active = true;
    this.final = false;
  }
  //#endregion
  //************************************************************************************************* */
  ngOnInit() {
    this.service.DomainData().subscribe((k) => {
      this.domainData = k;
    });
    this.service.GetAllUser().subscribe((k) => {
      this.userData = k;
    });
    this.dateD = new Date();
   this.Snow = environment.SNow;
  }
  //#region CreateUser
  CreateUser(tabData: any) {
    for (let key in tabData.value) {
      if (tabData.value[key] === '' || tabData.value[key] === null) {
        delete tabData.value[key];
      }
    }
    this.spinner.show();
    this.service.createaduser(tabData.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(
            'Active Directory User Created successfully.',
            'Success'
          );
          this.spinner.hide();
          this.urlreload();
          this.service.GetAllUser().subscribe((k) => {
            this.userData = k;
          });
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
        }
      }
    );
    tabData.form.reset();
  }
  //#endregion
  //#region UpdateUser
  UpdateUser(tabData: any) {
    for (let key in tabData.value) {
      if (tabData.value[key] === '' || tabData.value[key] === null) {
        delete tabData.value[key];
      }
    }
    this.spinner.show();
    this.service.Updateaduser(tabData.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(
            'Active Directory User Updated successfully.',
            'Success'
          );
          this.spinner.hide();
          this.urlreload();
          this.reset();
          this.service.GetAllUser().subscribe((k) => {
            this.userData = k;
          });
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
        }
      }
    );
    tabData.form.reset();
  }
  //#endregion
  //#region TrackUser
  trackByFn(index: number, item: any) {
    return index;
  }
  onUserSelection(ev: any, dc: any, ua: any, event: any) {
    // this.isChecked = false;
    this.isChecked = !this.isChecked;
    this.continue = !event.target.checked;
    this.UserPrincipleNameForAction = ev;
    this.DomainCodeForAction = dc;
    this.IsEnableForAction = ua;
  }
  onUserSelection1(k: any) {
    for (var i = 0; i < this.userData.length; i++) {
      this.isChecked = false;
    }
    this.isChecked = !this.isChecked;

    // this.continue = !event.target.checked;
    // this.UserPrincipleNameForAction = ev;
    // this.DomainCodeForAction = dc;
    // this.IsEnableForAction = ua;
  }
  onOUSelection(OU: any, event: any) {
    this.continue = !event.target.checked;
    this.OUNameForAction = OU;
  }
  onOUGroupSelection(OU: any, event: any) {
    this.continue = !event.target.checked;
    this.OUGroupNameForAction = OU;
  }

  //#endregion
  //#region UserADReset
  reset() {
    this.SearchUserForAction = false;
    this.AllActions = true;
    this.ADUserActionBasket = false;
    this.done = false;
    this.active = false;
    this.final = false;
    this.ActionName = 0;
    this.firstName = '';
    this.initials = '';
    this.lastName = '';
    this.office = '';
    this.userPrincipalName = '';
    this.telephoneNumber = '';
    this.webPage = '';
    this.domainCode = '';
    this.descriptionD = '';
    this.continue = true;
    this.AddressDetails[0].value;
    this.countryRegionCode = null;
    this.notess = '';
    for (let index = 0; index < this.AddressDetails.length; index++) {
      this.AddressDetails[index].value = null;
    }
    for (let index = 0; index < this.Details.length; index++) {
      this.Details[index].value = null;
    }
  }
  resetOU() {
    this.SearchOUForAction = false;
    this.AllActions = true;
    this.OUActionBasket = false;
    this.done = false;
    this.active = false;
    this.final = false;
    this.ActionName = 0;
  }
  //#endregion
  //#region GettoUpdateData
  GetADDataForProceed(ActionName: any) {
    if (ActionName == 3) {
      this.userDataEdit = this.userData.filter(
        (k: any) => k.userPrincipalName == this.UserPrincipleNameForAction
      );

      this.descriptionD = this.userDataEdit[0].description;
      this.domainCode = this.userDataEdit[0].domainCode;
      this.firstName = this.userDataEdit[0].firstName;
      this.initials = this.userDataEdit[0].initials;
      this.lastName = this.userDataEdit[0].lastName;
      this.notess = this.userDataEdit[0].notes;
      this.office = this.userDataEdit[0].office;

      this.AddressDetails[0].value = this.userDataEdit[0].street;
      this.AddressDetails[1].value = this.userDataEdit[0].pobox;
      this.AddressDetails[2].value = this.userDataEdit[0].city;
      this.AddressDetails[3].value = this.userDataEdit[0].stateProvince;
      this.AddressDetails[4].value = this.userDataEdit[0].zipPostalCode;

      this.Details[0].value = this.userDataEdit[0].jobTitle;
      this.Details[1].value = this.userDataEdit[0].department;
      this.Details[2].value = this.userDataEdit[0].company;
      this.Details[3].value = this.userDataEdit[0].homePhoneNumber;
      this.Details[4].value = this.userDataEdit[0].pager;
      this.Details[5].value = this.userDataEdit[0].mobile;
      this.Details[6].value = this.userDataEdit[0].fax;
      this.Details[7].value = this.userDataEdit[0].ipPhone;

      // this.street = this.userDataEdit[0].street;
      this.countryRegionCode = this.userDataEdit[0].countryRegionCode;
      this.manager = this.userDataEdit[0].manager;
      this.telephoneNumber = this.userDataEdit[0].telephoneNumber;
      this.userPrincipalName = this.userDataEdit[0].userPrincipalName;
      this.webPage = this.userDataEdit[0].webPage;
    }

    if (ActionName == 5) {
      this.service.GetOUList(this.DomainCodeForAction).subscribe((k) => {
        this.ouData = k;
      });
    }
  }
  //#endregion
  //#region DeleteAdUser
  DeleteADUser(requestType: any, DC: any) {
    var model = {
      domainCode: DC,
      userPrincipalName: this.UserPrincipleNameForAction,
      requestType: requestType,
    };
    Swal.fire({
      text: 'Are you sure to Delete User?',
      icon: 'warning',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Delete',
      showCancelButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        if (result.value) {
          this.service.aduserstatus(model).subscribe(
            (k: any) => {
              if (k.statusCode === 201) {
                this.toastr.success(k.message, 'Success');
                this.service.GetAllUser().subscribe((k) => {
                  this.userData = k;
                });
                this.urlreload();
              }
            },
            (err: HttpErrorResponse) => {
              if (err.status === 400) {
                this.toastr.error(err.error.message, 'Failed');
                this.urlreload();
              }
            }
          );
        }
      } else if (result.dismiss) {
      }
    });
  }
  //#endregion
  //#region Other Requests
  ChangeUserStatus(requestType: any, DC: any) {
    // let Domain = this.UserPrincipleNameForAction.substring(
    //   this.UserPrincipleNameForAction.indexOf('@') + 1
    // );
    var model = {
      domainCode: DC,
      userPrincipalName: this.UserPrincipleNameForAction,
      requestType: requestType,
    };
    console.log(model);
    this.service.aduserstatus(model).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.service.GetAllUser().subscribe((k) => {
            this.userData = k;
          });
        }
      },
      (err: HttpErrorResponse) => {
        console.log(err.error);
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
        }
      }
    );
    this.reset();
  }
  //#endregion
  //#region Move User
  MoveUser(ou: any, DC: any) {
    var model = {
      domainCode: DC,
      userPrincipalName: this.UserPrincipleNameForAction,
      organizationalUnit: ou,
    };
    console.log(model);
    this.service.Moveaduserou(model).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
        }
      },
      (err: HttpErrorResponse) => {
        console.log(err.error);
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
        }
      }
    );
    this.reset();
  }
  //#endregion
  //#region EnableDisableUser
  CheckUncheck(e: any, DC: any, note: any) {
    if (e.target.checked) {
      var model = {
        domainCode: DC,
        snowTaskId: this.sysIdforAction,
        userPrincipalName: this.UserPrincipleNameForAction,
        requestType: 'EnableADUser',
        notes: note
      };

      Swal.fire({
        text: 'Are you sure to enable a user?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Enable',
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          if (result.value) {
            this.service.aduserstatus(model).subscribe(
              (k: any) => {
                if (k.statusCode === 201) {
                  this.toastr.success(k.message, 'Success');
                  this.urlreload();
                  this.reset();
                  this.service.SnowCloseTask(JSON.stringify(this.sysIdforAction)).subscribe();
                  this.service.GetAllUser().subscribe((k) => {
                    this.userData = k;
                  });
                }
              },
              (err: HttpErrorResponse) => {
                if (err.status === 400) {
                  this.toastr.error(err.error.message, 'Failed');
                  this.urlreload();
                  this.reset();
                }
              }
            );
          }
        } else if (result.dismiss) {
          this.urlreload();
          this.reset();
        }
      });
    } else {
      var model = {
        domainCode: DC,
        snowTaskId: this.sysIdforAction,
        userPrincipalName: this.UserPrincipleNameForAction,
        requestType: 'DisableADUser',
        notes: note

      };

      Swal.fire({
        text: 'Are you sure to disable a user?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Disable',
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          if (result.value) {
            this.service.aduserstatus(model).subscribe(
              (k: any) => {
                if (k.statusCode === 201) {
                  this.toastr.success(k.message, 'Success');
                  this.urlreload();
                  this.reset();
                  this.service.SnowCloseTask(JSON.stringify(this.sysIdforAction)).subscribe();
                  this.service.GetAllUser().subscribe((k) => {
                    this.userData = k;
                  });
                }
              },
              (err: HttpErrorResponse) => {
                if (err.status === 400) {
                  this.toastr.error(err.error.message, 'Failed');
                  this.urlreload();
                  this.reset();
                }
              }
            );
          }
        } else if (result.dismiss) {
          this.urlreload();
          this.reset();
        }
      });
    }
  }
  //#endregion
  //#region UrlReload
  urlreload() {
    this.router
      .navigateByUrl('/sidebar', { skipLocationChange: true })
      .then(() => {
        this.router.navigate(['/management/actions']);
      });
  }
  //#endregion
  //#region ExtendUser
  ExtendUser(ou: any, DC: any, dt: any) {
    var model = {
      domainCode: DC,
      userPrincipalName: ou,
      extendedDate: dt,
    };
    console.log(model);
    this.service.ExtendUserDate(model).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
        }
      },
      (err: HttpErrorResponse) => {
        console.log(err.error);
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
        }
      }
    );
    this.reset();
  }
  //#endregion
  //#region GenerateUserPrincipal
  getRandomInt(min: any, max: any): number {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  onLastNameChange(dc: any, fName: any, event: any) {
    if (this.ActionName !== 3) {
      this.spinner.show();
      var upn = fName + event.target.value.substring(0, 1);
      var model = {
        domainCode: dc,
        userPrincipalName: upn,
      };
      this.service.CheckADUerExist(model).subscribe(
        (k: any) => {
          if (k.message == 'Available') {
            this.spinner.hide();
            this.userPrincipalName = upn;
          } else {
            var upn1 = fName + event.target.value.substring(0, 2);
            var model = {
              domainCode: dc,
              userPrincipalName: upn1,
            };
            this.service.CheckADUerExist(model).subscribe((k: any) => {
              if (k.message == 'Available') {
                this.spinner.hide();

                this.userPrincipalName = upn1;
              } else {
                var upn2 =
                  fName.substring(0, 1) + event.target.value.substring(0, 1);
                var model = {
                  domainCode: dc,
                  userPrincipalName: upn2,
                };
                this.service.CheckADUerExist(model).subscribe((k: any) => {
                  if (k.message == 'Available') {
                    this.spinner.hide();

                    this.userPrincipalName = upn2;
                  } else {
                    this.spinner.hide();

                    this.userPrincipalName = upn + this.getRandomInt(0, 9);
                  }
                });
              }
            });
          }
        },
        (err: HttpErrorResponse) => {
          if (err.status === 404) {
            this.userPrincipalName = upn + Math.random();
          }
        }
      );
    }
  }
  //#endregion
  //#region CreateOU
  onManageByTypeSelection(ev: any, dcc: any) {
    if (ev.target.value == "User") {
      this.manageByType = "User";
    }
    else if (ev.target.value == "Group") {
      this.manageByType = "Group";
      this.service.GetADGroupList(dcc).subscribe((k) => {
        this.adGroupData = k;
      });
    }
  }
  PostCreateOU(createOUForm: any) {

    console.log(createOUForm.value);

    for (let key in createOUForm.value) {
      if (createOUForm.value[key] === '' || createOUForm.value[key] === null) {
        delete createOUForm.value[key];
      }
    }
    this.spinner.show();
    this.service.CreateOU(createOUForm.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.urlreload();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.urlreload();
        }
      }
    );
    createOUForm.form.reset();
  }
  //#endregion
  //#region DeleteOu
  PostDeleteOU(OU: any, DC: any) {
    var model = {
      domainCode: DC,
      organizationalUnitName: OU,
    };
    Swal.fire({
      text: 'Are you sure to Delete OU?',
      icon: 'warning',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Delete',
      showCancelButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        if (result.value) {
          this.service.DeleteOU(model).subscribe(
            (k: any) => {
              if (k.statusCode === 201) {
                this.toastr.success(k.message, 'Success');
                this.urlreload();

              }
            },
            (err: HttpErrorResponse) => {
              if (err.status === 400) {
                this.toastr.error(err.error.message, 'Failed');
              }
            }
          );
        }
      } else if (result.dismiss) {
      }
    });
  }
  //#endregion
  //#region CreateUpdateDeleteOuGroup
  onOUSelect(ev: any) {
    this.service.GetOUList(ev.target.value).subscribe((k) => {
      this.ouData = k;
    });
  }
  PostCreateOUGroup(createOUGroupForm: any) {
    if (createOUGroupForm.value.requestType == "DeleteADOUGroup") {
      Swal.fire({
        text: 'Are you sure to Delete OU Group?',
        icon: 'warning',
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Delete',
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          if (result.value) {
            this.service.ManageOUGroup(createOUGroupForm.value).subscribe(
              (k: any) => {
                if (k.statusCode === 201) {
                  this.toastr.success(k.message, 'Success');
                  this.spinner.hide();
                  this.urlreload();
                }
              },
              (err: HttpErrorResponse) => {
                if (err.status === 400) {
                  this.toastr.error(err.error.message, 'Failed');
                  this.spinner.hide();
                  this.urlreload();
                }
              }
            );


          }
        } else if (result.dismiss) {
        }
      });
    }
    else {
      this.spinner.show();
      this.service.ManageOUGroup(createOUGroupForm.value).subscribe(
        (k: any) => {
          if (k.statusCode === 201) {
            this.toastr.success(k.message, 'Success');
            this.spinner.hide();
            this.urlreload();
          }
        },
        (err: HttpErrorResponse) => {
          if (err.status === 400) {
            this.toastr.error(err.error.message, 'Failed');
            this.spinner.hide();
            this.urlreload();
          }
        }
      );
    }
  }
  //#endregion
  //#region GetDataforUpdateOU
  GetOUDataForProceed(ActionName: any) {
    if (ActionName == 2) {
      this.service.GetOUListDetails(this.DomainCodeForAction).subscribe((k) => {
        this.ouData = k;
        this.userDataEdit = this.ouData.filter(
          (kk: any) => kk.organizationalUnitName == this.OUNameForAction
        );
        this.organizationalUnitName = this.userDataEdit[0].organizationalUnitName;
        this.domainCode = this.userDataEdit[0].domainCode;
        this.organizationalUnitDescription = this.userDataEdit[0].organizationalUnitDescription;
        this.ouManagedByType = this.userDataEdit[0].ouManagedByType;
        this.ManagedBy = this.userDataEdit[0].ouManagedBy;
        this.countryRegionCode = this.userDataEdit[0].country;
        this.city = this.userDataEdit[0].city;
        this.street = this.userDataEdit[0].street;
        this.stateProvince = this.userDataEdit[0].state;
        this.zipPostalCode = this.userDataEdit[0].postalCode;

      });


    }

    if (ActionName == 5) {
      this.service.GetOUList(this.DomainCodeForAction).subscribe((k) => {
        this.ouData = k;
      });
    }

  }
  //#endregion
  //#region GetDataforUpdateOUGroup
  GetOUGroupDataForProceed(ActionName: any) {
    if (ActionName == 3 || ActionName == 4) {
      this.userDataEdit = this.ouGrouoData.filter(
        (kk: any) => kk.name == this.OUGroupNameForAction
      );
      this.groupName = this.userDataEdit[0].name;
      this.domainCode = this.DomainCodeForAction;
      this.organizationalUnit = this.OUForAction;
      this.displayName = this.userDataEdit[0].displayName;
      this.description = this.userDataEdit[0].description;
    }

  }
  //#endregion
  saple(event: any) {
    event.target.value = event.target.value.replace(/\s+/g, ' ');
  }

  //#region ResetPassword
  createSignupForm(): FormGroup {
    return this.fb.group(
      {
        password: [
          null,
          Validators.compose([
            Validators.required,
            CustomValidators.patternValidator(/\d/, {
              hasNumber: true,
            }),
            CustomValidators.patternValidator(/[A-Z]/, {
              hasCapitalCase: true,
            }),
            CustomValidators.patternValidator(/[a-z]/, {
              hasSmallCase: true,
            }),
            CustomValidators.patternValidator(
              /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
              {
                hasSpecialCharacters: true,

              }
            ),
            Validators.minLength(8),
          ]),
        ],
        confirmPassword: [null, Validators.compose([Validators.required])],
      },
      {
        validator: CustomValidators.passwordMatchValidator,
      }
    );
  }
  onPassowrdSubmit(userForm: any) {
    let pass = this.frmreset.get('password');
    let objuserForm = {
      domainCode: userForm.value.domainCode,
      userPrincipalName: userForm.value.userPrincipalName,
      password: pass?.value,
    };
    this.service.ChangeUserPassword(objuserForm).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
        }
      }
    );
    this.reset();
  }
  //#endregion
  toggleBulk() {
    this.isShown2 = false;
    this.isShown = false;
    this.isShown3 = false;
    this.isShownOU = false;
    this.isShownBulk = !this.isShownBulk;
  }

  //#region File
  onFileDropped($event: any) {
    this.prepareFilesList($event);
  }
  fileBrowseHandler(ev: any) {
    this.prepareFilesList(ev.target.files);
  }
  deleteFile(index: number) {
    this.files.splice(index, 1);
  }
  uploadFilesSimulator(index: number) {
    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.uploadFilesSimulator(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      let mimetype = item['type'];
      if (mimetype == 'text/csv' || mimetype == 'application/vnd.ms-excel') {
        item.progress = 0;
        this.files.push(item);
      } else {
        this.toastr.warning('warning', 'Only CSV Files are Allowed');
      }
    }
    this.uploadFilesSimulator(0);
  }
  formatBytes(bytes: any) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed()) + ' ' + sizes[i];
  }
  downloadMyFile() {
    const link = document.createElement('a');
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'assets/img/dnd/Sample.csv');
    link.setAttribute('download', `Sample.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  //#endregion
  //#region BulkRequest
  PostBulk(Bulk: any) {
    this.service.CreateBulkRequest(this.files, Bulk.value.DomainCode, Bulk.value.RequestType).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.BulkReqData = k.result;
          this.toggleLiveDemo();
          this.spinner.hide();
          this.resetOU();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.resetOU();
        }
      });
  }
  //#endregion
  GetTaskDetails(taskNumber: any) {
    let dt: any = {};
    this.service.SnowTaskDetails(taskNumber.value).subscribe((k: any) => {
      dt = k;
      this.taskData = dt.result[0];
      this.IsTaskshow = true;

      console.log(this.taskData.assignedTo);

      // if (this.taskData.approval == "approved" && (this.taskData.assignedTo == "" || this.taskData.assignedTo == null) && (this.taskData.state == "1" || this.taskData.state == "2")) {
      //   this.IsAssign = false;
      //   this.sysIdforAction = this.taskData.sysId;
      // }

      if (this.taskData.approval == "approved" && (this.taskData.state == "1" || this.taskData.state == "2")) {
        this.IsAssign = false;
        this.sysIdforAction = this.taskData.sysId;
      }
    });
  }
  Assigntask() {
    this.service.SnowAssignTask(JSON.stringify(this.sysIdforAction)).subscribe();
  }
  CreateTicket() {


    var model = {
      active: true,
      description: "Enable/Disable",
      shortDescription: "Enable/Disable",
      openedAt: ""
    };
    let dt: any = {};
    this.service.CreateTicket(model).subscribe(
      (k: any) => {
        dt = k;
        this.taskData = dt.result[0];
        this.IsTaskshow = true;
        if (this.taskData.approval == "approved" && (this.taskData.state == "1" || this.taskData.state == "2")) {
          this.IsAssign = false;
          this.sysIdforAction = this.taskData.sysId;
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
        }
      }
    );
  }

}

