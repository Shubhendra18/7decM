import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import {
  faEnvelope,
  faLocationDot,
  faRotate,
  faRotateRight,
} from '@fortawesome/free-solid-svg-icons';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MapserviceService } from 'src/app/mapservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-SCCM',
  templateUrl: './SCCM.component.html',
  styleUrls: ['./SCCM.component.scss'],
})
export class SCCMComponent implements OnInit {
  public password1: any = '';
  public password: any = '';
  public isPasswordInvalid: boolean = true;

  faLocationDot = faLocationDot;
  faEnvelope = faEnvelope;
  faRotateRight = faRotateRight;
  faRotate = faRotate;
  isShown: boolean = false;
  isShown2: boolean = false;
  isShown3: boolean = false;
  isShown4: boolean = false;
  istabActive: boolean = true;
  CreateOU: any = 'CreateOU';
  isShownOU: boolean = false;
  isChecked: boolean = false;
  //#region UserAD Vars
  AllActions: boolean = false;
  SearchOUForAction: boolean = false;

  OUActionBasket: boolean = false;
  done: boolean = false;
  active: boolean = false;
  final: boolean = false;

  public visible = false;
  domainData: any = [];
  defaultdomain = null;

  userData: any = [];
  userDataEdit: any = {};
  defaultuser = null;

  ouData: any = [];
  defaultOu = null;

  defaultCountry = null;
  searchedKeyword: string = '';
  defaultComputer: any = null;
  defaultPrimaryUser: any = null;

  continue: boolean = true;
  ActionName: number = 0;
  DomainCodeForAction: string = '';
  IsEnableForAction: boolean = false;
  OUNameForAction: string = '';

  computerData: any = [];
  softwareData: any = [];
  installedSoftwareData: any = [];
  primaryUserData: any = [];
  allRoleData: any = [];
  IssoftwareData: boolean = false;
  isDeleteInSccm: boolean = true;

  //#endregion



  constructor(
    private sanitizer: DomSanitizer,
    private service: MapserviceService,
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {
    this.AllActions = true;
    this.done = false;
    this.final = false;
  }

  //#region  ToggleCode
  toggleShow() {
    this.isShown2 = false;
    this.isShown3 = false;
    this.isShownOU = false;
    this.isShown = !this.isShown;
  }
  toggleShow2() {
    this.isShown = false;
    this.isShown3 = false;
    this.isShownOU = false;
    this.isShown2 = !this.isShown2;
  }
  toggleShowOU() {
    this.isShown2 = false;
    this.isShown = false;
    this.isShown3 = false;
    this.isShownOU = !this.isShownOU;
  }
  AdUserAction(an: number) {
    this.AllActions = false;
    this.searchedKeyword = '';

    this.isShown = false;
    this.isShown2 = false;
    this.isShown3 = !this.isShown3;

    this.done = true;
    this.active = true;

    this.ActionName = an;
  }

  continueOU() {
    this.AllActions = false;
    this.SearchOUForAction = false;

    this.done = true;
    this.active = true;
    this.final = true;
    this.OUActionBasket = !this.OUActionBasket;
    this.searchedKeyword = '';
    this.continue = false;
  }

  toggleLiveDemo() {
    this.visible = !this.visible;
  }

  handleLiveDemoChange(event: any) {
    this.visible = event;
  }

  backOU() {
    this.SearchOUForAction = false;
    this.AllActions = true;
    this.done = false;
    this.active = false;
    this.final = false;
    this.continue = true;
    this.OUActionBasket = false;
  }

  backtoOUSearch() {
    this.SearchOUForAction = true;
    this.OUActionBasket = false;
    this.done = true;
    this.active = true;
    this.final = false;
  }
  //#endregion
  //************************************************************************************************* */
  ngOnInit() {
    this.service.DomainData().subscribe((k) => {
      this.domainData = k;
    });
    this.service.GetAllUser().subscribe((k) => {
      this.userData = k;
    });
  }
  //#region TrackUser
  trackByFn(index: number, item: any) {
    return index;
  }
  //#endregion
  //#region UserADReset
  resetOU() {
    this.SearchOUForAction = false;
    this.AllActions = true;
    this.OUActionBasket = false;
    this.done = false;
    this.active = false;
    this.final = false;
    this.ActionName = 0;
  }
  //#endregion

  //#region UrlReload
  urlreload() {
    this.router
      .navigateByUrl('/sidebar', { skipLocationChange: true })
      .then(() => {
        this.router.navigate(['/management/SCCM']);
      });
  }
  //#endregion

  //#region Create Computer
  PostCreateComputer(tabData: any) {
    console.log(tabData.value);
    for (let key in tabData.value) {
      if (tabData.value[key] === '' || tabData.value[key] === null) {
        delete tabData.value[key];
      }
    }
    this.spinner.show();
    this.service.CreateComputer(tabData.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.urlreload();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.urlreload();
        }
      }
    );
  }
  //#endregion

  onSCCM(an: number) {
    this.ActionName = an;
    if (an == 1 || an == 4) {
      this.service.GetAllPrimaryUser().subscribe((k) => {
        this.primaryUserData = k;
      });
      this.service.GetAllRoleCollection().subscribe((k) => {
        this.allRoleData = k;
      });

    }
    if (an == 2 || an == 3 || an == 4) {
      this.service.GetAllComputer().subscribe((k) => {
        this.computerData = k;
      });
      this.service.GetAllSoftware().subscribe((k) => {
        this.softwareData = k;
      });

    }
    if (an == 4) {
      this.service.GetAllComputerForPrimaryUser().subscribe((k) => {
        this.computerData = k;
      });
    }
  }
  saple(event: any) {
    event.target.value = event.target.value.replace(/\s+/g, ' ');
  }
  onComputerSelect(ev: any) {
    this.IssoftwareData = true;
    this.service.GetAllInstalledSoftware().subscribe((k) => {
      this.installedSoftwareData = k;
      this.installedSoftwareData = (this.installedSoftwareData.filter((kk: any) => kk.computerName == ev.target.value))
    });

  }
  //#region InstallSoftware
  PostInstallSoftware(tabData: any) {
    this.spinner.show();
    this.service.InstallSoftware(tabData.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.urlreload();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.urlreload();
        }
      }
    );
  }
  //#endregion
  //#region DeleteComputer
  PostDeleteComputer(DeleteData: any) {
    console.log(DeleteData.value);
    Swal.fire({
      text: 'Are you sure to Delete Computer?',
      icon: 'warning',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Delete',
      showCancelButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        if (result.value) {
          this.service.DeleteComputer(DeleteData.value).subscribe(
            (k: any) => {
              if (k.statusCode === 201) {
                this.toastr.success(k.message, 'Success');
                this.urlreload();
              }
            },
            (err: HttpErrorResponse) => {
              if (err.status === 400) {
                this.toastr.error(err.error.message, 'Failed');
                this.urlreload();
              }
            }
          );
        }
      } else if (result.dismiss) {
      }
    });
  }
  //#endregion
  PostAddPrimaryUser(UserData: any) {
    console.log(UserData.value);
    this.spinner.show();
    this.service.AddPrimaryUser(UserData.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.urlreload();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.urlreload();
        }
      }
    );
  }
}
