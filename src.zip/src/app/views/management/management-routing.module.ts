import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ActionComponent } from './action/action.component';
import { ExchangeComponent } from './exchange/exchange.component';
import { SCCMComponent } from './SCCM/SCCM.component';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Management',
    },

    children: [
      {
        path: '',
        redirectTo: 'actions',

      },
      {
        path: 'actions',
        component: ActionComponent,
        data: {
          title: 'Active Directory',
        },
      },
      {
        path: 'O365',
        component: ExchangeComponent,
        data: {
          title: 'O365',
        },
      },
      {
        path: 'SCCM',
        component: SCCMComponent,
        data: {
          title: 'SCCM',
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagementRoutingModule {}

