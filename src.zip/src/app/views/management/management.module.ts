import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {
  BadgeModule,
  ButtonModule,
  CardModule,
  CollapseModule,
  FormModule,
  GridModule,
  ListGroupModule,
  ModalModule,
  NavModule,
  OffcanvasModule,
  PlaceholderModule,
  ProgressModule,
  SharedModule,
  SpinnerModule,
  TabsModule,
  PopoverModule
} from '@coreui/angular';
import { DataTablesModule } from 'angular-datatables';
import { ReactiveFormsModule } from '@angular/forms';

import { FormsModule } from '@angular/forms';
import { IconModule } from '@coreui/icons-angular';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgSelectModule } from '@ng-select/ng-select';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ActionComponent } from './action/action.component';
import { ExchangeComponent } from './exchange/exchange.component';
import { ProgressComponent } from './progress/progress.component';
import { SCCMComponent } from './SCCM/SCCM.component';
import { ManagementRoutingModule } from './management-routing.module';
import { NgxTrimDirectiveModule } from 'ngx-trim-directive';
import { AlphaOnlyDirective } from '../../resources/alphaonly.directive';
import { BlockCopyPasteDirective } from '../../resources/block-copy.directive';
import { DndDirective } from '../../resources/dnd.directive';

@NgModule({
  imports: [
    ReactiveFormsModule,
    CommonModule,
    ManagementRoutingModule,
    BadgeModule,
    ButtonModule,
    CardModule,
    CollapseModule,
    GridModule,
    SharedModule,
    ListGroupModule,
    IconModule,
    ListGroupModule,
    PlaceholderModule,
    ProgressModule,
    SpinnerModule,
    TabsModule,
    NavModule,
    FormModule,
    FormsModule,
    ModalModule,
    OffcanvasModule,
    DataTablesModule,
    NgxSpinnerModule,
    FontAwesomeModule,
    Ng2SearchPipeModule,
    NgSelectModule,
    NgxTrimDirectiveModule,
    PopoverModule
  ],
  declarations: [ActionComponent,ExchangeComponent,SCCMComponent,ProgressComponent, AlphaOnlyDirective,DndDirective, BlockCopyPasteDirective],
})
export class ManagementModule {}
