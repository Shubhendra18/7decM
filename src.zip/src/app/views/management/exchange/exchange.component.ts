import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import {
  faEnvelope,
  faL,
  faLocationDot,
  faRotate,
  faRotateRight,
} from '@fortawesome/free-solid-svg-icons';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MapserviceService } from 'src/app/mapservice.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-exchnage',
  templateUrl: './exchange.component.html',
  styleUrls: ['./exchange.component.scss'],
})
export class ExchangeComponent implements OnInit {
  public password1: any = '';
  public password: any = '';
  public isPasswordInvalid: boolean = true;

  faLocationDot = faLocationDot;
  faEnvelope = faEnvelope;
  faRotateRight = faRotateRight;
  faRotate = faRotate;
  isShown: boolean = false;
  isShown2: boolean = false;
  isShown3: boolean = false;
  isShown4: boolean = false;
  istabActive: boolean = true;
  isShownDG: boolean = false;
  isChecked: boolean = false;
  //#region UserAD Vars
  AllActions: boolean = false;
  SearchDGForAction: boolean = false;

  DGActionBasket: boolean = false;
  done: boolean = false;
  active: boolean = false;
  final: boolean = false;

  public visible = false;
  domainData: any = [];
  defaultdomain = null;

  userData: any = [];
  userDataEdit: any = {};
  defaultuser = null;

  DGData: any = [];
  defaultOu = null;

  defaultCountry = null;
  searchedKeyword: string = '';
  countryRegionCode: any = null;
  countryCode: string = '';
  ManagedBy: any = null;

  continue: boolean = true;
  ActionName: number = 0;
  UserPrincipleNameForAction: string = '';
  DomainCodeForAction: string = '';
  IsEnableForAction: boolean = false;
  DGNameForAction: string = '';
  //#endregion

  //#region CreateDGModel
  name: string = '';
  displayName: string = '';
  description: string = '';
  emailAddress: string = '';
  owner: any = null;
  groupType: any = null;
  securityEnabled: boolean = true;
  mailEnabled: boolean = true;
  proxyAddresses: any = null;
  visibility: any = null;

  EmailEnable: boolean = false;
  //#endregion

  constructor(
    private sanitizer: DomSanitizer,
    private service: MapserviceService,
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {
    this.AllActions = true;
    this.done = false;
    this.final = false;
  }

  //#region  ToggleCode

  toggleShowDG() {
    this.isShown2 = false;
    this.isShown = false;
    this.isShown3 = false;
    this.isShownDG = !this.isShownDG;
  }

  continueDG() {
    this.AllActions = false;
    this.SearchDGForAction = false;

    this.done = true;
    this.active = true;
    this.final = true;
    this.DGActionBasket = !this.DGActionBasket;
    this.searchedKeyword = '';
    this.continue = false;
  }
  DGAction(an: number) {
    this.service.GetDGList().subscribe((k) => {
      this.DGData = k;
    });
    this.AllActions = false;
    this.SearchDGForAction = true;
    this.searchedKeyword = '';

    this.done = true;
    this.active = true;
    this.ActionName = an;
  }
  backDG() {
    this.SearchDGForAction = false;
    this.AllActions = true;
    this.done = false;
    this.active = false;
    this.final = false;
    this.continue = true;
    this.DGActionBasket = false;
  }

  backtoDGSearch() {
    this.SearchDGForAction = true;
    this.DGActionBasket = false;
    this.done = true;
    this.active = true;
    this.final = false;
  }
  //#endregion
  //************************************************************************************************* */
  ngOnInit() {
    this.service.DomainData().subscribe((k) => {
      this.domainData = k;
    });
    this.service.GetDUusersList().subscribe((k) => {
      this.userData = k;
    });
  }
  onSelect(ev: any) {
    if (ev.target.value == "Unified")
      this.EmailEnable = true;
    else
      this.EmailEnable = false;

  }

  //#region TrackUser
  trackByFn(index: number, item: any) {
    return index;
  }
  onDGSelection(DG: any, event: any) {
    this.continue = !event.target.checked;
    this.DGNameForAction = DG;
  }

  //#endregion
  //#region Reset
  resetDG() {
    this.SearchDGForAction = false;
    this.AllActions = true;
    this.DGActionBasket = false;
    this.done = false;
    this.active = false;
    this.final = false;
    this.ActionName = 0;
  }
  saple(event: any) {
    event.target.value = event.target.value.replace(/\s+/g, ' ');
    this.emailAddress = event.target.value

  }
  ff(event: any) {
    this.emailAddress = event.target.value
  }
  keyPressAlphaNumericWithCharacters(event:any) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9-_]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
 
  //#endregion
  //#region UrlReload
  urlreload() {
    this.router
      .navigateByUrl('/sidebar', { skipLocationChange: true })
      .then(() => {
        this.router.navigate(['/management/O365']);
      });
  }
  //#endregion
  //#region Create DG
  PostCreateDG(createDGForm: any) {
    for (let key in createDGForm.value) {
      if (createDGForm.value[key] === '' || createDGForm.value[key] === null) {
        delete createDGForm.value[key];
      }
    }
    this.spinner.show();
    this.service.CreateDG(createDGForm.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.resetDG();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.resetDG();
        }
      }
    );
    createDGForm.form.reset();
  }
  //#endregion
  //#region Delete DG
  DeleteDG(DG: any) {
    var model = {
      displayName: DG,
    };

    Swal.fire({
      text: 'Are you sure to Delete Distribution Group?',
      icon: 'warning',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Delete',
      showCancelButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        if (result.value) {
          this.service.DeleteDG(model).subscribe(
            (k: any) => {
              if (k.statusCode === 201) {
                this.toastr.success(k.message, 'Success');
                this.service.GetDGList().subscribe((k) => {
                  this.userData = k;
                });
                this.urlreload();
              }
            },
            (err: HttpErrorResponse) => {
              if (err.status === 400) {
                this.toastr.error(err.error.message, 'Failed');
                this.urlreload();
              }
            }
          );
        }
      } else if (result.dismiss) {
      }
    });
  }
  //#endregion
  //#region Update DG
  PostUpdateDG(createDGForm: any) {
    for (let key in createDGForm.value) {
      if (createDGForm.value[key] === '' || createDGForm.value[key] === null) {
        delete createDGForm.value[key];
      }
    }
    this.spinner.show();
    this.service.UpdateDG(createDGForm.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.urlreload();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.urlreload();
        }
      }
    );
    createDGForm.form.reset();
  }
  //#endregion
  //#region GetDataforUpdate
  GetDGDataForProceed(ActionName: any) {
    if (ActionName == 2) {
      this.DGData = this.DGData.filter(
        (k: any) => k.displayName == this.DGNameForAction
      );
      this.name = this.DGData[0].name;
      this.displayName = this.DGData[0].displayName;
      this.description = this.DGData[0].description;
      this.emailAddress = this.DGData[0].emailAddress;
      this.owner = this.DGData[0].owner;
      this.groupType = this.DGData[0].groupType;
      this.visibility = this.DGData[0].visibility;
      this.securityEnabled = this.DGData[0].securityEnabled;
      this.mailEnabled = this.DGData[0].mailEnabled;
    }
  }
  //#endregion
  //#region Add Member to DG
  PostAddMemberDG(createDGForm: any) {
    for (let key in createDGForm.value) {
      if (createDGForm.value[key] === '' || createDGForm.value[key] === null) {
        delete createDGForm.value[key];
      }
    }
    this.spinner.show();
    this.service.AddMemberToDG(createDGForm.value).subscribe(
      (k: any) => {
        if (k.statusCode === 201) {
          this.toastr.success(k.message, 'Success');
          this.spinner.hide();
          this.resetDG();
        }
      },
      (err: HttpErrorResponse) => {
        if (err.status === 400) {
          this.toastr.error(err.error.message, 'Failed');
          this.spinner.hide();
          this.resetDG();
        }
      }
    );
    createDGForm.form.reset();
  }
  //#endregion 
  //#region Delete Member to DG
  PostDeleteMemberDG(createDGForm: any) {
    Swal.fire({
      text: 'Are you sure to Delete Member from Distribution Group?',
      icon: 'warning',
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Delete',
      showCancelButton: true,
    }).then((result) => {
      if (result.isConfirmed) {
        if (result.value) {
          this.spinner.show();
          this.service.DeleteMemberToDG(createDGForm.value).subscribe(
            (k: any) => {
              if (k.statusCode === 201) {
                this.toastr.success(k.message, 'Success');
                this.spinner.hide();
                this.resetDG();
              }
            },
            (err: HttpErrorResponse) => {
              if (err.status === 400) {
                this.toastr.error(err.error.message, 'Failed');
                this.spinner.hide();
                this.resetDG();
              }
            }
          );
        }
      } else if (result.dismiss) {
      }
    });
  }
  //#endregion


}
