export class DisplayMsg {
  statusCode: number;
  response: string;
  error: string;
  message: string;
  result: any;
}
