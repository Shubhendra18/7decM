import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MapserviceService {
  //private baseUrl = 'http://10.2.0.7/dwp/map/api/';
  private baseUrl = 'http://10.2.0.4/dwp/map/api/';
  //private baseUrl = 'http://172.31.2.25/dwp/map/api/';

  constructor(private http: HttpClient) { }
  Login(logindata: any) {
    return this.http.post(this.baseUrl + 'authentication/login', logindata);
  }
  createaduser(CreateAdData: any) {
    return this.http.post(this.baseUrl + 'ad/createaduser', CreateAdData);
  }
  Updateaduser(CreateAdData: any) {
    return this.http.post(this.baseUrl + 'ad/updateaduser', CreateAdData);
  }
  aduserstatus(statusData: any) {
    return this.http.post(this.baseUrl + 'ad/aduserstatus', statusData);
  }
  DomainData() {
    return this.http.get(this.baseUrl + 'ad/getalladdomain');
  }
  GetAllUser() {
    return this.http.get(this.baseUrl + 'ad/getalladuser');
  }

  Moveaduserou(moveUserData: any) {
    return this.http.post(this.baseUrl + 'ad/moveaduserou', moveUserData);
  }
  ExtendUserDate(UserData: any) {
    return this.http.post(
      this.baseUrl + 'ad/extenduserexpirationdate',
      UserData
    );
  }

  ChangeUserPassword(UserData: any) {
    return this.http.post(this.baseUrl + 'ad/resetaduserpassword', UserData);
  }
  CheckADUerExist(UserData: any) {
    return this.http.post(
      this.baseUrl + 'ad/checkadusernameavailable',
      UserData
    );
  }
  CreateBulkRequest(fileToUpload: any, DomainCode: any, RequestType: any) {
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      formData.append("csvBulkUserFile", fileToUpload[i]);
    }
    formData.append('RequestType', RequestType);
    formData.append('DomainCode', DomainCode);
    return this.http.post(this.baseUrl + 'ad/bulkaduserstatus', formData);
  }
  //***************************************OU API*************/
  GetADGroupList(DomainCode: any) {
    return this.http.get(
      this.baseUrl + 'ad/getadgrouplist?DomainCode=' + DomainCode
    );
  }
  CreateOU(OUData: any) {
    return this.http.post(this.baseUrl + 'ad/createupdateou', OUData);
  }
  GetOUList(DomainCode: any) {
    return this.http.get(
      this.baseUrl + 'ad/activedirectoryoulist?DomainCode=' + DomainCode
    );
  }
  GetOUListDetails(DomainCode: any) {
    return this.http.get(
      this.baseUrl + 'ad/getadoulistdetails?DomainCode=' + DomainCode
    );
  }
  DeleteOU(OUData: any) {
    return this.http.post(this.baseUrl + 'ad/deleteou', OUData);
  }
  ManageOUGroup(OUData: any) {
    return this.http.post(this.baseUrl + 'ad/manageadougroup', OUData);
  }
  Getadougroupslist(DomainCode: any, OUName: any) {
    return this.http.get(
      this.baseUrl + 'ad/getadougroupslist?DomainCode=' + DomainCode + "&OUName=" + OUName
    );
  }
  //***************************************Report Dashboard*************/
  GetReport() {
    return this.http.get(this.baseUrl + 'report/getReport');
  }
  GetPieReport() {
    return this.http.get(this.baseUrl + 'report/getCurrentMonthStatus');
  }
  GetRequestReport() {
    return this.http.get(this.baseUrl + 'report/getRequestReport');
  }
  GetValueRealizationReport() {
    return this.http.get(this.baseUrl + 'report/GetValueRealizationReport');
  }

  //***************************************Exchnage API*************/

  GetDGList() {
    return this.http.get(this.baseUrl + 'exchange/getalldistributiongroup');
  }
  GetDUusersList() {
    return this.http.get(this.baseUrl + 'exchange/getallexchangeuser');
  }
  DeleteDG(DGData: any) {
    return this.http.post(
      this.baseUrl + 'exchange/deletedistributiongroup',
      DGData
    );
  }
  CreateDG(DGData: any) {
    return this.http.post(
      this.baseUrl + 'exchange/createdistributiongroup',
      DGData
    );
  }
  UpdateDG(DGData: any) {
    return this.http.post(
      this.baseUrl + 'exchange/updatedistributiongroup',
      DGData
    );
  }

  AddMemberToDG(DGData: any) {
    return this.http.post(
      this.baseUrl + 'exchange/addmembertodistibutiongroup',
      DGData
    );
  }
  DeleteMemberToDG(DGData: any) {
    return this.http.post(
      this.baseUrl + 'exchange/deletememberfromdistibutiongroup',
      DGData
    );
  }

  //***************************************SCCM API*************/
  GetAllPrimaryUser() {
    return this.http.get(
      this.baseUrl + 'sccm/getallprimaryuser'
    );
  }
  GetAllRoleCollection() {
    return this.http.get(
      this.baseUrl + 'sccm/getallrolecollection'
    );
  }
  CreateComputer(SccmData: any) {
    return this.http.post(
      this.baseUrl + 'sccm/CreateComputer',
      SccmData
    );
  }
  GetAllComputer() {
    return this.http.get(
      this.baseUrl + 'sccm/getallcomputer'
    );
  }
  GetAllSoftware() {
    return this.http.get(
      this.baseUrl + 'sccm/getallsoftware'
    );
  }
  GetAllInstalledSoftware() {
    return this.http.get(
      this.baseUrl + 'sccm/getallinstalledsoftware'
    );
  }
  InstallSoftware(Data: any) {
    return this.http.post(
      this.baseUrl + 'sccm/InstallSoftware',
      Data
    );
  }
  DeleteComputer(Data: any) {
    return this.http.post(
      this.baseUrl + 'sccm/DeleteComputer',
      Data
    );
  }
  GetAllComputerForPrimaryUser() {
    return this.http.get(
      this.baseUrl + 'sccm/getallcomputerforprimaryuser'
    );
  }
  AddPrimaryUser(SccmData: any) {
    return this.http.post(
      this.baseUrl + 'sccm/addprimaryusertocomputer',
      SccmData
    );
  }

  //***************************************SNOW**************** */
  SnowTaskDetails(Taskno: any) {
    return this.http.get(
      this.baseUrl + 'snow/SearchSCTask/' + Taskno
    );
  }
  SnowAssignTask(sysId: any) {
    return this.http.put(
      this.baseUrl + 'snow/AssignSCTask', sysId, { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    );
  }
  SnowCloseTask(sysId: any) {
    return this.http.put(
      this.baseUrl + 'snow/CloseSCTask', sysId, { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) }
    );
  }
  CreateTicket(Data: any) {
    return this.http.post(
      this.baseUrl + 'snow/CreateSR',
      Data
    );
  }
}
