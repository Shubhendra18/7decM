import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[alpha]',
})
export class AlphaOnlyDirective {
  key: any;
  @HostListener('keydown', ['$event']) onkeydown(e: KeyboardEvent) {
    this.key = e.keyCode;
    if (
      (this.key >= 15 && this.key <= 64 ) ||
      (this.key >= 123 ) ||
      (this.key >= 96 && this.key <= 105 )
    )
      e.preventDefault();
  }
}
