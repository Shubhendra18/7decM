import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
  },

  {
    name: 'Management',
    url: '/management',
    iconComponent: { name: 'cil-settings' },
    children: [
      {
        name: 'Active Directory',
        url: '/management/actions',
      },
      {
        name: 'O365',
        url: '/management/O365',
      },
      {
        name: 'SCCM',
        url: '/management/SCCM',
      },
    ]
    
  },
  {
    name: 'Reports',
    url: '/reports',
    iconComponent: { name: 'cilChart' },
    children: [
      {
        name: 'Request Status',
        url: '/reports/request-status',
      },
      {
        name: 'Value Realization',
        url: '/reports/value-realization',
      },
    ],
  },
  {
    name: 'Logout',
    url: '/logout',
    iconComponent: { name: 'cilLockLocked' },
  },
];

export const navItemsAdmin: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
  },
  {
    name: 'User Management',
    url: '/superadmin/user-management',
    iconComponent: { name: 'cilUserFollow' },
  },
  {
    name: 'Configuration',
    url: '/superadmin',
    iconComponent: { name: 'cilSettings' },
    children: [
      {
        name: 'Add Domain',
        url: '/superadmin/add-domain',
      },
      {
        name: 'API Config',
        url: '/superadmin/api-config',
      },

    ],
  },
  {
    name: 'Reports',
    url: '/reports',
    iconComponent: { name: 'cilChart' },
    children: [
      {
        name: 'Request Status',
        url: '/reports/request-status',
      },
      {
        name: 'Value Realization',
        url: '/reports/value-realization',
      },
    ],
  },
  {
    name: 'Logout',
    url: '/logout',
    iconComponent: { name: 'cilLockLocked' },
  },
];
