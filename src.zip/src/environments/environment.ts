export const environment = {
  production: false,
  SNow: true
};

