export const environment = {
  production: true,
  SNow: true

};
